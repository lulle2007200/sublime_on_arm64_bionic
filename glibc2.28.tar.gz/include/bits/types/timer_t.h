#ifndef __timer_t_defined
#define __timer_t_defined 1

#include <bits/types.h>

/* Timer ID returned by `timer_create'.  */
typedef __timer_t timer_t;

#endif
